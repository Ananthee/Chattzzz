'use strict'
console.log("start of home controller")
                 
                	 

                		app.controller('AboutController', function($scope) {
                		  $scope.message = 'Hello from AboutController';
                		});  
                	  
		
		
                		app.controller('HomeController', function($scope) {
                  		  $scope.message = 'Hello from HomeController';
                  		});  
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
